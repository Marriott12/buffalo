# Buffalo Marathon 2025 - Deployment Guide

## Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- Mail server or SMTP access

## Installation Steps

1. **Clone/Upload Files**
   ```bash
   git clone [repository-url] buffalo-marathon
   cd buffalo-marathon