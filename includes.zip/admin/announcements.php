<?php
require_once '../includes/functions.php';
requireAdmin();

$page_title = 'Announcements Management';
$db = getDB();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        setFlash('error', 'Invalid request. Please try again.');
    } else {
        if ($action === 'create') {
            $title = sanitize($_POST['title'] ?? '');
            $content = $_POST['content'] ?? ''; // Allow HTML content
            $excerpt = sanitize($_POST['excerpt'] ?? '');
            $is_featured = isset($_POST['is_featured']) ? 1 : 0;
            $is_published = isset($_POST['is_published']) ? 1 : 0;
            
            if (empty($title) || empty($content)) {
                setFlash('error', 'Title and content are required.');
            } else {
                try {
                    $stmt = $db->prepare("
                        INSERT INTO announcements (title, content, excerpt, is_featured, is_published, created_by) 
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$title, $content, $excerpt, $is_featured, $is_published, $_SESSION['user_id']]);
                    
                    logActivity('announcement_created', "Created announcement: {$title}");
                    setFlash('success', 'Announcement created successfully.');
                } catch (Exception $e) {
                    setFlash('error', 'Error creating announcement.');
                }
            }
        } elseif ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $title = sanitize($_POST['title'] ?? '');
            $content = $_POST['content'] ?? '';
            $excerpt = sanitize($_POST['excerpt'] ?? '');
            $is_featured = isset($_POST['is_featured']) ? 1 : 0;
            $is_published = isset($_POST['is_published']) ? 1 : 0;
            
            if (empty($title) || empty($content)) {
                setFlash('error', 'Title and content are required.');
            } else {
                try {
                    $stmt = $db->prepare("
                        UPDATE announcements 
                        SET title = ?, content = ?, excerpt = ?, is_featured = ?, is_published = ?, updated_at = NOW() 
                        WHERE id = ?
                    ");
                    $stmt->execute([$title, $content, $excerpt, $is_featured, $is_published, $id]);
                    
                    logActivity('announcement_updated', "Updated announcement: {$title}");
                    setFlash('success', 'Announcement updated successfully.');
                } catch (Exception $e) {
                    setFlash('error', 'Error updating announcement.');
                }
            }
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            
            try {
                $stmt = $db->prepare("DELETE FROM announcements WHERE id = ?");
                $stmt->execute([$id]);
                
                logActivity('announcement_deleted', "Deleted announcement ID: {$id}");
                setFlash('success', 'Announcement deleted successfully.');
            } catch (Exception $e) {
                setFlash('error', 'Error deleting announcement.');
            }
        }
    }
    
    header('Location: announcements.php');
    exit();
}

// Get announcements
$stmt = $db->query("
    SELECT a.*, u.first_name, u.last_name 
    FROM announcements a 
    LEFT JOIN users u ON a.created_by = u.id 
    ORDER BY a.created_at DESC
");
$announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get specific announcement for editing
$edit_announcement = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $stmt = $db->prepare("SELECT * FROM announcements WHERE id = ?");
    $stmt->execute([$edit_id]);
    $edit_announcement = $stmt->fetch(PDO::FETCH_ASSOC);
}

include '../includes/header.php';
?>

<div class="container-fluid p-0">
    <div class="row g-0">
        <!-- Admin Sidebar -->
        <div class="col-lg-2 col-md-3">
            <div class="admin-sidebar">
                <div class="px-3 mb-4">
                    <h6 class="text-white mb-0">
                        <i class="fas fa-cog me-2"></i>Admin Panel
                    </h6>
                    <small class="text-white-50">Buffalo Marathon 2025</small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="participants.php">
                        <i class="fas fa-users me-2"></i>Participants
                    </a>
                    <a class="nav-link" href="payments.php">
                        <i class="fas fa-credit-card me-2"></i>Payments
                    </a>
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar me-2"></i>Schedule
                    </a>
                    <a class="nav-link active" href="announcements.php">
                        <i class="fas fa-bullhorn me-2"></i>Announcements
                    </a>
                    <a class="nav-link" href="categories.php">
                        <i class="fas fa-list me-2"></i>Categories
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    <a class="nav-link" href="settings.php">
                        <i class="fas fa-cogs me-2"></i>Settings
                    </a>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-10 col-md-9">
            <div class="admin-content">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="display-6 text-army-green mb-0">
                            <i class="fas fa-bullhorn me-2"></i>Announcements
                        </h1>
                        <p class="text-muted mb-0">Manage event announcements and updates</p>
                    </div>
                    <div>
                        <button class="btn btn-army-green" data-bs-toggle="modal" data-bs-target="#announcementModal">
                            <i class="fas fa-plus me-1"></i>New Announcement
                        </button>
                    </div>
                </div>
                
                <!-- Announcements List -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">All Announcements</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>Title</th>
                                        <th>Status</th>
                                        <th>Featured</th>
                                        <th>Created By</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($announcements as $announcement): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo htmlspecialchars($announcement['title']); ?></strong>
                                            <?php if ($announcement['excerpt']): ?>
                                                <br><small class="text-muted">
                                                    <?php echo htmlspecialchars(substr($announcement['excerpt'], 0, 100)); ?>...
                                                </small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo $announcement['is_published'] ? 'bg-success' : 'bg-secondary'; ?>">
                                                <?php echo $announcement['is_published'] ? 'Published' : 'Draft'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($announcement['is_featured']): ?>
                                                <i class="fas fa-star text-warning"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($announcement['first_name'] . ' ' . $announcement['last_name']); ?></td>
                                        <td><?php echo date('M j, Y', strtotime($announcement['created_at'])); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="?edit=<?php echo $announcement['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-sm btn-outline-danger" 
                                                        onclick="deleteAnnouncement(<?php echo $announcement['id']; ?>)">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Announcement Modal -->
<div class="modal fade" id="announcementModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?php echo $edit_announcement ? 'Edit' : 'Create'; ?> Announcement
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="action" value="<?php echo $edit_announcement ? 'update' : 'create'; ?>">
                <?php if ($edit_announcement): ?>
                    <input type="hidden" name="id" value="<?php echo $edit_announcement['id']; ?>">
                <?php endif; ?>
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Title *</label>
                        <input type="text" class="form-control" id="title" name="title" 
                               value="<?php echo htmlspecialchars($edit_announcement['title'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="excerpt" class="form-label">Excerpt</label>
                        <input type="text" class="form-control" id="excerpt" name="excerpt" 
                               value="<?php echo htmlspecialchars($edit_announcement['excerpt'] ?? ''); ?>"
                               placeholder="Brief summary for previews">
                    </div>
                    
                    <div class="mb-3">
                        <label for="content" class="form-label">Content *</label>
                        <textarea class="form-control" id="content" name="content" rows="10" required><?php echo htmlspecialchars($edit_announcement['content'] ?? ''); ?></textarea>
                        <small class="form-text text-muted">Basic HTML tags are allowed.</small>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_featured" name="is_featured" 
                                       <?php echo (!empty($edit_announcement['is_featured'])) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_featured">
                                    Featured Announcement
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="is_published" name="is_published" 
                                       <?php echo (!isset($edit_announcement) || $edit_announcement['is_published']) ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="is_published">
                                    Publish Immediately
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-army-green">
                        <?php echo $edit_announcement ? 'Update' : 'Create'; ?> Announcement
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Form -->
<form id="deleteForm" method="POST" style="display: none;">
    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="deleteId">
</form>

<script>
<?php if ($edit_announcement): ?>
// Show modal if editing
document.addEventListener('DOMContentLoaded', function() {
    var modal = new bootstrap.Modal(document.getElementById('announcementModal'));
    modal.show();
});
<?php endif; ?>

function deleteAnnouncement(id) {
    if (confirm('Are you sure you want to delete this announcement?')) {
        document.getElementById('deleteId').value = id;
        document.getElementById('deleteForm').submit();
    }
}
</script>

<?php include '../includes/footer.php'; ?>