<?php
require_once '../includes/functions.php';
requireAdmin();

$page_title = 'System Settings';
$db = getDB();

$errors = [];
$success = false;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    
    if (!validateCSRFToken($csrf_token)) {
        $errors[] = 'Invalid request. Please try again.';
    } else {
        $settings_to_update = [
            'site_maintenance',
            'registration_open',
            'max_participants',
            'contact_email',
            'contact_phone',
            'payment_instructions'
        ];
        
        try {
            $db->beginTransaction();
            
            foreach ($settings_to_update as $key) {
                $value = $_POST[$key] ?? '';
                
                // Validation
                if ($key === 'contact_email' && !empty($value) && !isValidEmail($value)) {
                    $errors[] = 'Please enter a valid contact email';
                    continue;
                }
                
                if ($key === 'max_participants' && !empty($value) && (!is_numeric($value) || $value < 1)) {
                    $errors[] = 'Maximum participants must be a positive number';
                    continue;
                }
                
                updateSetting($key, $value, $_SESSION['user_id']);
            }
            
            if (empty($errors)) {
                $db->commit();
                logActivity('settings_updated', 'System settings updated');
                $success = true;
            } else {
                $db->rollback();
            }
            
        } catch (Exception $e) {
            $db->rollback();
            $errors[] = 'Error updating settings. Please try again.';
        }
    }
}

// Get current settings
$current_settings = [];
$stmt = $db->query("SELECT setting_key, setting_value FROM settings");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $current_settings[$row['setting_key']] = $row['setting_value'];
}

include '../includes/header.php';
?>

<div class="container-fluid p-0">
    <div class="row g-0">
        <!-- Admin Sidebar -->
        <div class="col-lg-2 col-md-3">
            <div class="admin-sidebar">
                <div class="px-3 mb-4">
                    <h6 class="text-white mb-0">
                        <i class="fas fa-cog me-2"></i>Admin Panel
                    </h6>
                    <small class="text-white-50">Buffalo Marathon 2025</small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="participants.php">
                        <i class="fas fa-users me-2"></i>Participants
                    </a>
                    <a class="nav-link" href="payments.php">
                        <i class="fas fa-credit-card me-2"></i>Payments
                    </a>
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar me-2"></i>Schedule
                    </a>
                    <a class="nav-link" href="announcements.php">
                        <i class="fas fa-bullhorn me-2"></i>Announcements
                    </a>
                    <a class="nav-link" href="categories.php">
                        <i class="fas fa-list me-2"></i>Categories
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    <a class="nav-link active" href="settings.php">
                        <i class="fas fa-cogs me-2"></i>Settings
                    </a>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-10 col-md-9">
            <div class="admin-content">
                <!-- Header -->
                <div class="mb-4">
                    <h1 class="display-6 text-army-green mb-0">
                        <i class="fas fa-cogs me-2"></i>System Settings
                    </h1>
                    <p class="text-muted mb-0">Configure Buffalo Marathon 2025 system settings</p>
                </div>
                
                <!-- Flash Messages -->
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i>Settings updated successfully!
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Please fix the following errors:</strong>
                        <ul class="mb-0 mt-2">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <div class="row">
                        <!-- General Settings -->
                        <div class="col-lg-6">
                            <div class="card mb-4">
                                <div class="card-header bg-army-green text-white">
                                    <h5 class="mb-0">General Settings</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label class="form-label">Site Maintenance Mode</label>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="site_maintenance" 
                                                   name="site_maintenance" value="1"
                                                   <?php echo ($current_settings['site_maintenance'] ?? '0') === '1' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="site_maintenance">
                                                Enable maintenance mode (disables public access)
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Marathon Registration</label>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="registration_open" 
                                                   name="registration_open" value="1"
                                                   <?php echo ($current_settings['registration_open'] ?? '1') === '1' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="registration_open">
                                                Allow new marathon registrations
                                            </label>
                                        </div>
                                        <small class="form-text text-muted">
                                            Note: Registration will automatically close on September 30, 2025
                                        </small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="max_participants" class="form-label">Maximum Participants</label>
                                        <input type="number" class="form-control" id="max_participants" 
                                               name="max_participants" min="1" 
                                               value="<?php echo htmlspecialchars($current_settings['max_participants'] ?? '1000'); ?>">
                                        <small class="form-text text-muted">
                                            Registration will close when this number is reached
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Contact Information -->
                        <div class="col-lg-6">
                            <div class="card mb-4">
                                <div class="card-header bg-army-green text-white">
                                    <h5 class="mb-0">Contact Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="contact_email" class="form-label">Contact Email</label>
                                        <input type="email" class="form-control" id="contact_email" 
                                               name="contact_email" 
                                               value="<?php echo htmlspecialchars($current_settings['contact_email'] ?? ''); ?>"
                                               placeholder="info@buffalo-marathon.com">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="contact_phone" class="form-label">Contact Phone</label>
                                        <input type="tel" class="form-control" id="contact_phone" 
                                               name="contact_phone" 
                                               value="<?php echo htmlspecialchars($current_settings['contact_phone'] ?? ''); ?>"
                                               placeholder="+260 XXX XXXXXXX">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Payment Instructions -->
                        <div class="col-12">
                            <div class="card mb-4">
                                <div class="card-header bg-army-green text-white">
                                    <h5 class="mb-0">Payment Instructions</h5>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="payment_instructions" class="form-label">
                                            Payment Instructions for Participants
                                        </label>
                                        <textarea class="form-control" id="payment_instructions" 
                                                  name="payment_instructions" rows="5"><?php echo htmlspecialchars($current_settings['payment_instructions'] ?? ''); ?></textarea>
                                        <small class="form-text text-muted">
                                            These instructions will be sent to participants after registration
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- System Information -->
                        <div class="col-12">
                            <div class="card mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0 text-army-green">System Information</h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <dl class="row">
                                                <dt class="col-sm-6">PHP Version:</dt>
                                                <dd class="col-sm-6"><?php echo PHP_VERSION; ?></dd>
                                                
                                                <dt class="col-sm-6">Database:</dt>
                                                <dd class="col-sm-6">
                                                    <?php 
                                                    try {
                                                        $version = $db->query('SELECT VERSION()')->fetchColumn();
                                                        echo 'MySQL ' . $version;
                                                    } catch (Exception $e) {
                                                        echo 'Connected';
                                                    }
                                                    ?>
                                                </dd>
                                                
                                                <dt class="col-sm-6">Server Time:</dt>
                                                <dd class="col-sm-6"><?php echo date('Y-m-d H:i:s T'); ?></dd>
                                            </dl>
                                        </div>
                                        <div class="col-md-6">
                                            <dl class="row">
                                                <dt class="col-sm-6">Total Users:</dt>
                                                <dd class="col-sm-6">
                                                    <?php echo number_format($db->query("SELECT COUNT(*) FROM users")->fetchColumn()); ?>
                                                </dd>
                                                
                                                <dt class="col-sm-6">Total Registrations:</dt>
                                                <dd class="col-sm-6">
                                                    <?php echo number_format($db->query("SELECT COUNT(*) FROM registrations WHERE payment_status != 'cancelled'")->fetchColumn()); ?>
                                                </dd>
                                                
                                                <dt class="col-sm-6">Disk Usage:</dt>
                                                <dd class="col-sm-6">
                                                    <?php 
                                                    $bytes = disk_total_space('.') - disk_free_space('.');
                                                    echo number_format($bytes / 1024 / 1024, 2) . ' MB used';
                                                    ?>
                                                </dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Save Button -->
                    <div class="d-flex justify-content-between align-items-center">
                        <button type="submit" class="btn btn-army-green btn-lg">
                            <i class="fas fa-save me-2"></i>Save Settings
                        </button>
                        
                        <div>
                            <button type="button" class="btn btn-outline-danger me-2" onclick="clearCache()">
                                <i class="fas fa-trash me-1"></i>Clear Cache
                            </button>
                            <button type="button" class="btn btn-outline-warning" onclick="backupDatabase()">
                                <i class="fas fa-download me-1"></i>Backup Database
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function clearCache() {
    if (confirm('Are you sure you want to clear the cache?')) {
        // Implementation for cache clearing
        showNotification('Cache cleared successfully', 'success');
    }
}

function backupDatabase() {
    if (confirm('Are you sure you want to create a database backup?')) {
        window.location.href = 'backup.php';
    }
}
</script>

<?php include '../includes/footer.php'; ?>