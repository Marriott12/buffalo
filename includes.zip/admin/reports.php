<?php
require_once '../includes/functions.php';
requireAdmin();

$page_title = 'Reports & Analytics';
$db = getDB();

// Handle export requests
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    $format = $_GET['format'] ?? 'csv';
    
    if ($export_type === 'participants') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=participants_' . date('Y-m-d') . '.csv');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, [
            'Registration Number', 'First Name', 'Last Name', 'Email', 'Phone', 
            'Category', 'Age', 'Gender', 'T-Shirt Size', 'Payment Status', 
            'Emergency Contact', 'Emergency Phone', 'Registered Date'
        ]);
        
        $stmt = $db->query("
            SELECT r.*, u.first_name, u.last_name, u.email, u.phone, c.name as category_name
            FROM registrations r
            JOIN users u ON r.user_id = u.id
            JOIN categories c ON r.category_id = c.id
            WHERE r.payment_status != 'cancelled'
            ORDER BY r.registered_at DESC
        ");
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [
                $row['registration_number'],
                $row['first_name'],
                $row['last_name'],
                $row['email'],
                $row['phone'],
                $row['category_name'],
                $row['age'],
                $row['gender'],
                $row['tshirt_size'],
                $row['payment_status'],
                $row['emergency_contact_name'],
                $row['emergency_contact_phone'],
                $row['registered_at']
            ]);
        }
        
        fclose($output);
        exit;
    }
}

// Get statistics
$stats = [];

// Basic counts
$stats['total_users'] = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$stats['total_registrations'] = $db->query("SELECT COUNT(*) FROM registrations WHERE payment_status != 'cancelled'")->fetchColumn();
$stats['paid_registrations'] = $db->query("SELECT COUNT(*) FROM registrations WHERE payment_status = 'paid'")->fetchColumn();
$stats['pending_registrations'] = $db->query("SELECT COUNT(*) FROM registrations WHERE payment_status = 'pending'")->fetchColumn();
$stats['total_revenue'] = $db->query("SELECT SUM(c.fee) FROM registrations r JOIN categories c ON r.category_id = c.id WHERE r.payment_status = 'paid'")->fetchColumn() ?? 0;

// Registration by category
$stmt = $db->query("
    SELECT c.name, COUNT(r.id) as count, SUM(c.fee) as revenue
    FROM categories c
    LEFT JOIN registrations r ON c.id = r.category_id AND r.payment_status != 'cancelled'
    GROUP BY c.id, c.name
    ORDER BY count DESC
");
$category_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Registration by gender
$stmt = $db->query("
    SELECT gender, COUNT(*) as count
    FROM registrations 
    WHERE payment_status != 'cancelled'
    GROUP BY gender
");
$gender_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Age distribution
$stmt = $db->query("
    SELECT 
        CASE 
            WHEN age < 18 THEN 'Under 18'
            WHEN age BETWEEN 18 AND 25 THEN '18-25'
            WHEN age BETWEEN 26 AND 35 THEN '26-35'
            WHEN age BETWEEN 36 AND 45 THEN '36-45'
            WHEN age BETWEEN 46 AND 55 THEN '46-55'
            ELSE '55+'
        END as age_group,
        COUNT(*) as count
    FROM registrations 
    WHERE payment_status != 'cancelled'
    GROUP BY age_group
    ORDER BY age_group
");
$age_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Registration trends (last 30 days)
$stmt = $db->query("
    SELECT DATE(registered_at) as date, COUNT(*) as count
    FROM registrations 
    WHERE registered_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(registered_at)
    ORDER BY date ASC
");
$daily_registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Payment methods
$stmt = $db->query("
    SELECT payment_method, COUNT(*) as count
    FROM registrations 
    WHERE payment_status = 'paid' AND payment_method IS NOT NULL
    GROUP BY payment_method
");
$payment_methods = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
?>

<div class="container-fluid p-0">
    <div class="row g-0">
        <!-- Admin Sidebar -->
        <div class="col-lg-2 col-md-3">
            <div class="admin-sidebar">
                <div class="px-3 mb-4">
                    <h6 class="text-white mb-0">
                        <i class="fas fa-cog me-2"></i>Admin Panel
                    </h6>
                    <small class="text-white-50">Buffalo Marathon 2025</small>
                </div>
                
                <nav class="nav flex-column">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="participants.php">
                        <i class="fas fa-users me-2"></i>Participants
                    </a>
                    <a class="nav-link" href="payments.php">
                        <i class="fas fa-credit-card me-2"></i>Payments
                    </a>
                    <a class="nav-link" href="schedule.php">
                        <i class="fas fa-calendar me-2"></i>Schedule
                    </a>
                    <a class="nav-link" href="announcements.php">
                        <i class="fas fa-bullhorn me-2"></i>Announcements
                    </a>
                    <a class="nav-link" href="categories.php">
                        <i class="fas fa-list me-2"></i>Categories
                    </a>
                    <a class="nav-link active" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    <a class="nav-link" href="settings.php">
                        <i class="fas fa-cogs me-2"></i>Settings
                    </a>
                </nav>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="col-lg-10 col-md-9">
            <div class="admin-content">
                <!-- Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="display-6 text-army-green mb-0">
                            <i class="fas fa-chart-bar me-2"></i>Reports & Analytics
                        </h1>
                        <p class="text-muted mb-0">Comprehensive marathon statistics and data exports</p>
                    </div>
                    <div class="dropdown">
                        <button class="btn btn-army-green dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-download me-1"></i>Export Data
                        </button>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?export=participants&format=csv">
                                <i class="fas fa-file-csv me-2"></i>Participants (CSV)
                            </a></li>
                            <li><a class="dropdown-item" href="?export=payments&format=csv">
                                <i class="fas fa-file-csv me-2"></i>Payments (CSV)
                            </a></li>
                            <li><a class="dropdown-item" href="?export=full_report&format=pdf">
                                <i class="fas fa-file-pdf me-2"></i>Full Report (PDF)
                            </a></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Key Metrics -->
                <div class="row mb-4">
                    <div class="col-lg-2 col-md-4 mb-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body text-center">
                                <i class="fas fa-users fa-2x mb-2"></i>
                                <h3><?php echo number_format($stats['total_registrations']); ?></h3>
                                <small>Total Participants</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 mb-3">
                        <div class="card bg-success text-white">
                            <div class="card-body text-center">
                                <i class="fas fa-check-circle fa-2x mb-2"></i>
                                <h3><?php echo number_format($stats['paid_registrations']); ?></h3>
                                <small>Confirmed</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 mb-3">
                        <div class="card bg-warning text-dark">
                            <div class="card-body text-center">
                                <i class="fas fa-clock fa-2x mb-2"></i>
                                <h3><?php echo number_format($stats['pending_registrations']); ?></h3>
                                <small>Pending</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 mb-3">
                        <div class="card bg-info text-white">
                            <div class="card-body text-center">
                                <i class="fas fa-money-bill-wave fa-2x mb-2"></i>
                                <h3><?php echo formatCurrency($stats['total_revenue']); ?></h3>
                                <small>Revenue</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 mb-3">
                        <div class="card bg-secondary text-white">
                            <div class="card-body text-center">
                                <i class="fas fa-user-plus fa-2x mb-2"></i>
                                <h3><?php echo number_format($stats['total_users']); ?></h3>
                                <small>Total Users</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 mb-3">
                        <div class="card bg-dark text-white">
                            <div class="card-body text-center">
                                <i class="fas fa-percentage fa-2x mb-2"></i>
                                <h3><?php echo $stats['total_registrations'] > 0 ? number_format(($stats['paid_registrations'] / $stats['total_registrations']) * 100, 1) : 0; ?>%</h3>
                                <small>Payment Rate</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Category Breakdown -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Registration by Category</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="categoryChart" width="400" height="200"></canvas>
                                
                                <div class="table-responsive mt-3">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Category</th>
                                                <th>Count</th>
                                                <th>Revenue</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($category_stats as $cat): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($cat['name']); ?></td>
                                                <td><?php echo number_format($cat['count']); ?></td>
                                                <td><?php echo formatCurrency($cat['revenue'] ?? 0); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Demographics -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Participant Demographics</h5>
                            </div>
                            <div class="card-body">
                                <!-- Gender Distribution -->
                                <h6 class="text-army-green">Gender Distribution</h6>
                                <?php foreach ($gender_stats as $gender): ?>
                                <div class="mb-2">
                                    <div class="d-flex justify-content-between">
                                        <span><?php echo htmlspecialchars($gender['gender']); ?></span>
                                        <span><?php echo number_format($gender['count']); ?></span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-army-green" 
                                             style="width: <?php echo $stats['total_registrations'] > 0 ? ($gender['count'] / $stats['total_registrations'] * 100) : 0; ?>%">
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                
                                <hr>
                                
                                <!-- Age Distribution -->
                                <h6 class="text-army-green">Age Groups</h6>
                                <?php foreach ($age_stats as $age): ?>
                                <div class="mb-2">
                                    <div class="d-flex justify-content-between">
                                        <span><?php echo htmlspecialchars($age['age_group']); ?></span>
                                        <span><?php echo number_format($age['count']); ?></span>
                                    </div>
                                    <div class="progress" style="height: 6px;">
                                        <div class="progress-bar bg-info" 
                                             style="width: <?php echo $stats['total_registrations'] > 0 ? ($age['count'] / $stats['total_registrations'] * 100) : 0; ?>%">
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Registration Trends -->
                    <div class="col-lg-8 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Registration Trends (Last 30 Days)</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="trendsChart" width="400" height="200"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Payment Methods -->
                    <div class="col-lg-4 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="mb-0">Payment Methods</h5>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($payment_methods)): ?>
                                    <?php foreach ($payment_methods as $method): ?>
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span><?php echo htmlspecialchars($method['payment_method'] ?? 'Not specified'); ?></span>
                                            <span class="badge bg-army-green"><?php echo number_format($method['count']); ?></span>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-muted">No payment data available.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Recent Activity Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="text-army-green">Today's Activity</h6>
                                <?php
                                $today_registrations = $db->query("SELECT COUNT(*) FROM registrations WHERE DATE(registered_at) = CURDATE()")->fetchColumn();
                                $today_payments = $db->query("SELECT COUNT(*) FROM payment_logs WHERE DATE(changed_at) = CURDATE() AND new_status = 'paid'")->fetchColumn();
                                ?>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-user-plus text-success me-2"></i><?php echo $today_registrations; ?> new registrations</li>
                                    <li><i class="fas fa-credit-card text-info me-2"></i><?php echo $today_payments; ?> payments confirmed</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-army-green">This Week</h6>
                                <?php
                                $week_registrations = $db->query("SELECT COUNT(*) FROM registrations WHERE registered_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn();
                                $week_revenue = $db->query("SELECT SUM(c.fee) FROM registrations r JOIN categories c ON r.category_id = c.id WHERE r.payment_status = 'paid' AND r.updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn() ?? 0;
                                ?>
                                <ul class="list-unstyled">
                                    <li><i class="fas fa-users text-primary me-2"></i><?php echo $week_registrations; ?> registrations</li>
                                    <li><i class="fas fa-money-bill-wave text-success me-2"></i><?php echo formatCurrency($week_revenue); ?> revenue</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Category Chart
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode(array_column($category_stats, 'name')); ?>,
        datasets: [{
            data: <?php echo json_encode(array_column($category_stats, 'count')); ?>,
            backgroundColor: [
                '#4B5320', '#8F9779', '#222B1F', '#5D6B3A', '#A5B088', '#3A4229'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Trends Chart
const trendsCtx = document.getElementById('trendsChart').getContext('2d');
new Chart(trendsCtx, {
    type: 'line',
    data: {
        labels: <?php echo json_encode(array_column($daily_registrations, 'date')); ?>,
        datasets: [{
            label: 'Daily Registrations',
            data: <?php echo json_encode(array_column($daily_registrations, 'count')); ?>,
            borderColor: '#4B5320',
            backgroundColor: 'rgba(75, 83, 32, 0.1)',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>

<?php include '../includes/footer.php'; ?>