<?php
require_once '../includes/functions.php';
requireAdmin();

$page_title = 'Participants Management';
$db = getDB();

// Handle AJAX requests
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    
    if ($_GET['ajax'] === 'update_payment') {
        $registration_id = (int)($_POST['registration_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $payment_method = $_POST['payment_method'] ?? '';
        $payment_reference = $_POST['payment_reference'] ?? '';
        $notes = $_POST['notes'] ?? '';
        
        if (!in_array($status, ['pending', 'paid', 'cancelled', 'refunded'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid status']);
            exit;
        }
        
        try {
            $db->beginTransaction();
            
            // Get current registration
            $stmt = $db->prepare("SELECT * FROM registrations WHERE id = ?");
            $stmt->execute([$registration_id]);
            $registration = $stmt->fetch();
            
            if (!$registration) {
                throw new Exception('Registration not found');
            }
            
            $old_status = $registration['payment_status'];
            
            // Update registration
            $stmt = $db->prepare("
                UPDATE registrations 
                SET payment_status = ?, payment_method = ?, payment_reference = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$status, $payment_method, $payment_reference, $registration_id]);
            
            // Log payment change
            $stmt = $db->prepare("
                INSERT INTO payment_logs (registration_id, old_status, new_status, payment_method, payment_reference, notes, changed_by)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$registration_id, $old_status, $status, $payment_method, $payment_reference, $notes, $_SESSION['user_id']]);
            
            // Send notification email if status changed to paid
            if ($status === 'paid' && $old_status !== 'paid') {
                $stmt = $db->prepare("
                    SELECT u.email, u.first_name, u.last_name, r.registration_number, c.name as category_name
                    FROM registrations r
                    JOIN users u ON r.user_id = u.id
                    JOIN categories c ON r.category_id = c.id
                    WHERE r.id = ?
                ");
                $stmt->execute([$registration_id]);
                $participant = $stmt->fetch();
                
                if ($participant) {
                    $subject = 'Payment Confirmed - Buffalo Marathon 2025';
                    $message = "
                        <h2>Payment Confirmed!</h2>
                        <p>Dear {$participant['first_name']},</p>
                        <p>Your payment for Buffalo Marathon 2025 has been confirmed!</p>
                        
                        <h3>What's Included in Your Registration:</h3>
                        <ul>
                            <li><strong>Branded Marathon T-Shirt</strong> - High-quality moisture-wicking fabric</li>
                            <li><strong>Finisher's Medal</strong> - Beautiful commemorative medal upon completion</li>
                            <li><strong>Race Number Bib</strong> - Official race identification with timing chip</li>
                            <li><strong>Free Drink Voucher</strong> - Refreshments during and after the race</li>
                        </ul>
                        
                        <h3>Event Day Activities:</h3>
                        <ul>
                            <li><strong>Pre & Post-Race Aerobics</strong> - Professional warm-up and cool-down sessions</li>
                            <li><strong>Live Entertainment</strong> - Zambia Army Pop Band and special guest artists</li>
                            <li><strong>Food & Drinks</strong> - Braai packs, food zones, chill lounge with local drinks and wine</li>
                            <li><strong>Kids Zone</strong> - Fun activities for children</li>
                        </ul>
                        
                        <p><strong>Registration Details:</strong><br>
                        Registration Number: {$participant['registration_number']}<br>
                        Category: {$participant['category_name']}<br>
                        Payment Method: {$payment_method}<br>
                        Reference: {$payment_reference}</p>
                        
                        <p>You will receive your race pack collection details closer to the event date.</p>
                        <p>See you at the marathon!</p>
                        <p>Best regards,<br>Buffalo Marathon Team</p>
                    ";
                    
                    sendEmail($participant['email'], $subject, $message);
                }
            }
            
            $db->commit();
            logActivity('payment_status_update', "Updated payment status for registration #{$registration_id} from {$old_status} to {$status}");
            
            echo json_encode(['success' => true, 'message' => 'Payment status updated successfully']);
            
        } catch (Exception $e) {
            $db->rollback();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
}

// Rest of participants.php code...
// [Previous participants.php code continues here]

<script>
function updatePayment(registrationId) {
    document.getElementById('registration_id').value = registrationId;
    var modal = new bootstrap.Modal(document.getElementById('paymentModal'));
    modal.show();
}

document.getElementById('paymentForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    formData.append('csrf_token', document.querySelector('meta[name="csrf-token"]').content);
    
    fetch('?ajax=update_payment', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => {
        alert('Error updating payment status');
    });
});
</script>

<?php include '../includes/footer.php'; ?>