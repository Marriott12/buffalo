// Main JavaScript file for Buffalo Marathon 2025

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initCountdown();
    initFormValidation();
    initTooltips();
    initSmoothScroll();
    initRegistrationForm();
    
    // Flash messages auto-hide
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            if (alert.classList.contains('alert-success') || alert.classList.contains('alert-info')) {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }
        });
    }, 5000);
});

// Countdown Timer
function initCountdown() {
    const countdownElements = {
        days: document.getElementById('countdown-days'),
        hours: document.getElementById('countdown-hours'),
        minutes: document.getElementById('countdown-minutes'),
        seconds: document.getElementById('countdown-seconds')
    };
    
    // Marathon date: October 11, 2025 07:00:00
    const marathonDate = new Date('2025-10-11T07:00:00').getTime();
    
    function updateCountdown() {
        const now = new Date().getTime();
        const distance = marathonDate - now;
        
        if (distance < 0) {
            // Marathon has started or passed
            Object.values(countdownElements).forEach(element => {
                if (element) element.textContent = '00';
            });
            return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        if (countdownElements.days) countdownElements.days.textContent = String(days).padStart(2, '0');
        if (countdownElements.hours) countdownElements.hours.textContent = String(hours).padStart(2, '0');
        if (countdownElements.minutes) countdownElements.minutes.textContent = String(minutes).padStart(2, '0');
        if (countdownElements.seconds) countdownElements.seconds.textContent = String(seconds).padStart(2, '0');
    }
    
    // Update countdown immediately and then every second
    updateCountdown();
    setInterval(updateCountdown, 1000);
}

// Form Validation
function initFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
    
    // Real-time validation
    const inputs = document.querySelectorAll('input[required], select[required], textarea[required]');
    inputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            validateField(input);
        });
        
        input.addEventListener('input', function() {
            if (input.classList.contains('is-invalid')) {
                validateField(input);
            }
        });
    });
}

function validateField(field) {
    const isValid = field.checkValidity();
    
    if (isValid) {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
    } else {
        field.classList.remove('is-valid');
        field.classList.add('is-invalid');
    }
    
    return isValid;
}

// Registration Form Specific
function initRegistrationForm() {
    const categorySelect = document.getElementById('category_id');
    const feeDisplay = document.getElementById('registration-fee');
    
    if (categorySelect && feeDisplay) {
        categorySelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const fee = selectedOption.dataset.fee;
            
            if (fee) {
                feeDisplay.textContent = 'K' + parseFloat(fee).toFixed(2);
                feeDisplay.parentElement.style.display = 'block';
            } else {
                feeDisplay.parentElement.style.display = 'none';
            }
        });
    }
    
    // Emergency contact validation
    const emergencyPhone = document.getElementById('emergency_contact_phone');
    if (emergencyPhone) {
        emergencyPhone.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9+\-\s]/g, '');
        });
    }
    
    // Age validation
    const ageInput = document.getElementById('age');
    if (ageInput) {
        ageInput.addEventListener('input', function() {
            const age = parseInt(this.value);
            const categorySelect = document.getElementById('category_id');
            
            if (age && categorySelect) {
                const selectedOption = categorySelect.options[categorySelect.selectedIndex];
                const categoryName = selectedOption.text;
                
                // Validate age against category
                if (categoryName.includes('Kid') && age > 17) {
                    showFieldError(this, 'Kids category is for ages 17 and under');
                } else if (!categoryName.includes('Kid') && age < 5) {
                    showFieldError(this, 'Minimum age is 5 years for this category');
                } else {
                    clearFieldError(this);
                }
            }
        });
    }
}

function showFieldError(field, message) {
    field.classList.add('is-invalid');
    
    let feedback = field.parentElement.querySelector('.invalid-feedback');
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        field.parentElement.appendChild(feedback);
    }
    feedback.textContent = message;
}

function clearFieldError(field) {
    field.classList.remove('is-invalid');
    field.classList.add('is-valid');
    
    const feedback = field.parentElement.querySelector('.invalid-feedback');
    if (feedback) {
        feedback.remove();
    }
}

// Initialize Tooltips
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Smooth Scroll
function initSmoothScroll() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            if (href === '#') {
                e.preventDefault();
                return;
            }
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Utility Functions
function showLoading(element) {
    const originalContent = element.innerHTML;
    element.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Loading...';
    element.disabled = true;
    
    return function hideLoading() {
        element.innerHTML = originalContent;
        element.disabled = false;
    };
}

function showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 100px; right: 20px; z-index: 9999; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Copy to clipboard function
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        showNotification('Copied to clipboard!', 'success');
    }, function() {
        showNotification('Failed to copy to clipboard', 'danger');
    });
}

// Format phone number
function formatPhoneNumber(phoneNumber) {
    const cleaned = phoneNumber.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    
    if (match) {
        return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    
    return phoneNumber;
}

// Confirm actions
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Admin functions
function updatePaymentStatus(registrationId, status) {
    const hideLoading = showLoading(event.target);
    
    fetch('admin/ajax/update-payment.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            registration_id: registrationId,
            status: status
        })
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showNotification('Payment status updated successfully!', 'success');
            location.reload();
        } else {
            showNotification('Error updating payment status: ' + data.message, 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        showNotification('Error updating payment status', 'danger');
        console.error('Error:', error);
    });
}

// Export functions for global use
window.showNotification = showNotification;
window.copyToClipboard = copyToClipboard;
window.confirmAction = confirmAction;
window.updatePaymentStatus = updatePaymentStatus;
window.showLoading = showLoading;